//
//  ftViewController.h
//  Good Deed Marathon
//
//  Created by Nishant on 07/11/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ftViewController : UIViewController
- (IBAction)next:(id)sender;

@property (weak, nonatomic) IBOutlet UIView *ftView;
@property (weak, nonatomic) IBOutlet UIScrollView *ftScrollView;
@end
