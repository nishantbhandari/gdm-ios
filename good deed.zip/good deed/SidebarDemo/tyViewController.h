//
//  tyViewController.h
//  Good Deed Marathon
//
//  Created by Nishant on 06/11/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface tyViewController : UIViewController{


}
@property (strong, nonatomic) IBOutlet UIScrollView *tyscroll;
@property (strong, nonatomic) IBOutlet UIView *tyview;
- (IBAction)share:(id)sender;

@end
